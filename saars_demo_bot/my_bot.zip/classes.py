global EVASION_DISTANCE
EVASION_DISTANCE= 6
from util import *

class World_Island(object):
    def __init__(self, island):
        self.island = island
        self.target = None
        
    def update_data(self, game):
        self.island = game.get_island(self.island.id)
        game.debug("Island {}, targeted by pirate {}".format(self.island.id, self.target))

        
class my_pirate(object):
    def __init__(self, pirate):
        self.pirate = pirate
        self.power = self.calculate_power()
        self.target = None
        
    def is_capturing(self):
        return game.is_capturing(self.pirate)
    
    def updata_data(self):
        pirate = game.get_my_pirate(self.pirate.id)
        self.power = self.calculate_power()
        if (self.pirate.is_lost):
            self.set_target(None)
        game.debug('id: {}; power: {}; target: {}'.format(self.pirate, self.power, self.target)) # WTF?

    def set_target(self, target):
        if target is None: # Ship is lost - release island
            if not self.target is None: 
                self.target.target = None # Release the target
            game.debug('id: {}. Given target is None. Target is changed from: {}'.format(self.pirate.id, '')) # WTF?
            self.target = target
        elif target.target is None: # Target exists and doesn't have a target yet
            if not self.target is None:
                self.target.target = None # Release current target
            game.debug('id: {}. Given target is {}. Target is changed from: {}'.format(self.pirate.id, target,island.id, '')) # WTF?
            self.target = target
            self.target.target = self
            
    def calculate_power(self):
        power = 0
        if not self.pirate.is_lost and not game.is_capturing(self.pirate): # If pirate is free
            pirates = game.my_pirates()
            power = 1
            for pirate in pirates:
                if (game.in_range(self.pirate, pirate) and not pirate.is_cloaked and not game.is_capturing(pirate)):
                    power += 1
        return power
    
    def move_towards_target(self, enemy_pirates):
        if not self.pirate.is_lost:
            game.set_sail(self.pirate, self.get_direction(enemy_pirates))
        
    def get_direction(self, enemy_pirates):
        close_enemies = filter(self.compare_fleets, enemy_pirates)
        if len(close_enemies): # If there's danger
            pivot = self.get_pivot(close_enemies) # Get "Escape route"
            directions = game.get_directions(self.pirate, pivot)
            return reverse_directions(directions[-1])
        if not self.target is None:
            return game.get_directions(self.pirate, self.target.island)[0]
        return '-'
    
    def get_pivot(self, pirates):
        total_weight = 0
        weights = []
        for enemy in pirates:
            temp = EVASION_DISTANCE - game.distance(self.pirate, enemy)
            total_weight += temp
            weights.append(temp)

        row, col = 0, 0
        for i in xrange(len(pirates)):
            col += (pirates[i].location.col*weights[i])
            row += (pirates[i].location.row*weights[i])
        col = int(col/total_weight)
        row = int(row/total_weight)
        return (row, col)

    def compare_fleets(self, enemy):
        return game.distance(self.pirate, other.enemy) < EVASION_DISTANCE and enemy.power >= self.power
    
class enemy_pirate(object):
    def __init__(self, pirate):
        self.pirate = pirate
        self.power = self.calculate_power()
        
    def is_capturing(self):
        return game.is_capturing(self)
    
    def update_data(self):
        pirate = game.get_enemy_pirate(self.pirate.id)
        self.power = self.calculate_power()
        
    def calculate_power(self):
        power = 0
        if not self.pirate.is_lost and game.is_capturing(self.pirate): # If pirate is free
            pirates = game.enemy_pirates()
            power = 1
            for pirate in pirates:
                if (game.in_range(self.pirate, pirate) and not pirate.is_cloaked and not game.is_capturing(pirate)):
                    power += 1
        return power
        
